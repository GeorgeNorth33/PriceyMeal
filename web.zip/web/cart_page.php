<!DOCTYPE html>
<html lang="ru">
<?php
session_start();
require 'includes/db_connection.php';

$version = '1.0' . time();

$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total = 0;

// Расчет общей суммы и получение названий магазинов
foreach ($cart_items as &$item) {
    if (!isset($item['store_name']) && isset($item['store_id'])) {
        $store_id = intval($item['store_id']);
        $store_query = "SELECT store_name FROM Store WHERE id_store = $store_id";
        $store_result = mysqli_query($connection, $store_query);
        if ($store_result && mysqli_num_rows($store_result) > 0) {
            $store_data = mysqli_fetch_assoc($store_result);
            $item['store_name'] = $store_data['store_name'];
        } else {
            $item['store_name'] = 'Неизвестный магазин';
        }
    }
    $total += $item['price'] * $item['quantity'];
}
unset($item);

// Обработка изменения количества
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_quantity'])) {
        $index = intval($_POST['item_index']);
        $quantity = intval($_POST['quantity']);
        
        if ($quantity > 0) {
            $_SESSION['cart'][$index]['quantity'] = $quantity;
        } else {
            unset($_SESSION['cart'][$index]);
            $_SESSION['cart'] = array_values($_SESSION['cart']);
        }
        
        header("Location: cart_page.php");
        exit();
    }
    
    if (isset($_POST['remove_item'])) {
        $index = intval($_POST['item_index']);
        unset($_SESSION['cart'][$index]);
        $_SESSION['cart'] = array_values($_SESSION['cart']);
        header("Location: cart_page.php");
        exit();
    }
    
    // ДОБАВЬТЕ ЭТОТ БЛОК ДЛЯ ОЧИСТКИ ВСЕЙ КОРЗИНЫ
    if (isset($_POST['clear_cart'])) {
        $_SESSION['cart'] = [];
        header("Location: cart_page.php");
        exit();
    }
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корзина - Pricey Meal</title>
    <link rel="stylesheet" href="/cart_page.css?=<?php echo $version?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="logo-container">
            <a href="index.php"><img src="img/logo_logo копия.png" alt="logo"></a>
        </div>

        <div class="header-actions">
            <div class="action-item">
                <a href="cart_page.php" class="action-icon"><img src="icons/icons8-cart-35 .png" alt="cart"></a>
                <a href="cart_page.php" class="action-label">Корзина</a>
                <?php if (!empty($cart_items)): ?>
                    <span class="cart-count"><?php echo count($cart_items); ?></span>
                <?php endif; ?>
            </div>
            <div class="action-item">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="profile.php" class="action-icon"><img src="icons/icons8-user-icon-35.png" alt="profile"></a>
                    <a href="profile.php" class="action-label">Профиль</a>
                <?php else: ?>
                    <a href="login.php" class="action-icon"><img src="icons/icons8-user-icon-35.png" alt="profile"></a>
                    <a href="login.php" class="action-label">Войти</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <div class="main-container">
        <div class="cart-page">
            
            <?php if (empty($cart_items)): ?>
                <div class="empty-cart">
                    <h2>Корзина пуста</h2>
                    <p>Добавьте товары из каталога</p>
                    <a href="index.php" class="continue-shopping-btn">Продолжить покупки</a>
                </div>
            <?php else: ?>
            
            <div class="cart-content">
                <!-- Левая колонка с товарами -->
                <div class="cart-items">
                    <?php foreach ($cart_items as $index => $item): ?>
                    <div class="cart-item">
                        <div class="item-image">
                            <img src="products_image/<?php echo htmlspecialchars($item['product_image']); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>" onerror="this.src='img/placeholder.jpg'">
                        </div>
                        <div class="item-info">
                            <h2 class="item-name"><?php echo htmlspecialchars($item['product_name']); ?></h2>
                            <div class="item-store">
                                <span class="store-icon">Магазин: </span>
                                <span class="store-name"><?php echo htmlspecialchars($item['store_name'] ?? 'Магазин не указан'); ?></span>
                            </div>
                        </div>
                        <div class="item-price">
                            <span class="price"><?php echo htmlspecialchars($item['price']); ?>₽</span>
                            <form method="POST" class="quantity-form">
                                <input type="hidden" name="item_index" value="<?php echo $index; ?>">
                                <div class="quantity-controls">
                                    <button type="submit" name="update_quantity" class="quantity-btn" 
                                            onclick="this.form.quantity.value=<?php echo $item['quantity'] - 1; ?>">-</button>
                                    <span class="quantity"><?php echo htmlspecialchars($item['quantity']); ?></span>
                                    <button type="submit" name="update_quantity" class="quantity-btn" 
                                            onclick="this.form.quantity.value=<?php echo $item['quantity'] + 1; ?>">+</button>
                                </div>
                                <input type="hidden" name="quantity" value="<?php echo $item['quantity']; ?>">
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Правая колонка с итогами -->
                <div class="cart-summary">
                    <div class="summary-card">
                        <h3 class="summary-title">Итого</h3>
                        <div class="summary-row">
                            <span>Товары (<?php echo count($cart_items); ?>)</span>
                            <span><?php echo number_format($total, 2); ?>₽</span>
                        </div>
                        <div class="summary-row">
                            <span>Скидка</span>
                            <span class="discount">-0₽</span>
                        </div>
                        <div class="summary-row total">
                            <span>Общая сумма</span>
                            <span><?php echo number_format($total, 2); ?>₽</span>
                        </div>
                        
                        <!-- Кнопка очистки всей корзины -->
                        <form method="POST" class="clear-cart-form">
                            <button type="submit" name="clear_cart" class="clear-cart-btn">
                                Очистить корзину
                            </button>
                        </form>
                    </div>
                </div>
                
            </div>
            
            <!-- Умные рекомендации на основе ценовых кластеров -->
            <div class="cart-recommendations">
                <h3>Персональные рекомендации</h3>
                
                <?php
                // Проверяем, существует ли файл с рекомендациями
                if (file_exists('includes/price_cluster_recommender.php')) {
                    require_once 'includes/price_cluster_recommender.php';
                    
                    // Создаем объект рекомендателя
                    $clusterRecommender = new PriceClusterRecommender($connection);
                    
                    // Анализируем профиль пользователя
                    $userProfile = $clusterRecommender->analyzeUserPriceProfile($cart_items);
                } else {
                    // Если файла нет, создаем базовый профиль
                    $prices = [];
                    foreach ($cart_items as $item) {
                        $prices[] = $item['price'];
                    }
                    
                    $userProfile = [
                        'type' => 'moderate',
                        'message' => 'Сбалансированный выбор',
                        'preference' => 'Средний ценовой сегмент',
                        'avg_price' => !empty($prices) ? round(array_sum($prices) / count($prices), 2) : 0
                    ];
                }
                ?>
                
                <div class="user-profile-badge">
                    <span class="profile-type">Профиль: <?php echo $userProfile['preference']; ?></span>
                    <span class="profile-desc"><?php echo $userProfile['message']; ?></span>
                    <span class="profile-avg">Средний чек: <?php echo $userProfile['avg_price']; ?> ₽</span>
                </div>
                
                <p>Подобрано на основе ваших ценовых предпочтений:</p>
                
                <div class="recommended-products-cluster">
                    <?php
                    if (isset($clusterRecommender)) {
                        $recommended = $clusterRecommender->getRecommendationsByPriceClusters($cart_items, 6);
                    } else {
                        // Простые рекомендации, если нет алгоритма
                        $cartPrices = [];
                        foreach ($cart_items as $item) {
                            $cartPrices[] = $item['price'];
                        }
                        
                        $avgPrice = !empty($cartPrices) ? array_sum($cartPrices) / count($cartPrices) : 0;
                        
                        // Простой SQL запрос для рекомендаций
                        $query = "SELECT p.*, MIN(ps.price) as min_price
                                  FROM Product p
                                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                                  WHERE ps.price BETWEEN " . ($avgPrice * 0.7) . " AND " . ($avgPrice * 1.3) . "
                                  GROUP BY p.id_product
                                  ORDER BY RAND()
                                  LIMIT 6";
                        
                        $recommended = mysqli_query($connection, $query);
                    }
                    
                    if ($recommended && mysqli_num_rows($recommended) > 0):
                        while ($product = mysqli_fetch_assoc($recommended)):
                            if ($userProfile['avg_price'] > 0) {
                                $priceDiff = abs($product['min_price'] - $userProfile['avg_price']);
                                $matchPercent = 100 - min(100, ($priceDiff / $userProfile['avg_price']) * 100);
                            } else {
                                $matchPercent = 80;
                            }
                    ?>
                    <div class="cluster-product-card">
                        <div class="match-badge" style="background: <?php 
                            echo $matchPercent > 80 ? '#2ecc71' : 
                                 ($matchPercent > 60 ? '#f39c12' : '#e74c3c'); 
                        ?>;">
                            <?php echo round($matchPercent); ?>% совпадение
                        </div>
                        
                        <div class="product-image">
                            <img src="products_image/<?php echo htmlspecialchars($product['image'] ?? 'placeholder.jpg'); ?>" 
                                 alt="<?php echo htmlspecialchars($product['Name']); ?>"
                                 onerror="this.src='img/placeholder.jpg'">
                        </div>
                        
                        <div class="product-details">
                            <h4><?php echo htmlspecialchars($product['Name']); ?></h4>
                            
                            <div class="price-info">
                                <span class="current-price"><?php echo $product['min_price']; ?> ₽</span>
                                <span class="price-compare">
                                    <?php if ($userProfile['avg_price'] > 0): ?>
                                        <?php if ($product['min_price'] < $userProfile['avg_price']): ?>
                                            <span class="cheaper">Дешевле на <?php echo round($userProfile['avg_price'] - $product['min_price']); ?> ₽</span>
                                        <?php elseif ($product['min_price'] > $userProfile['avg_price']): ?>
                                            <span class="expensive">Дороже на <?php echo round($product['min_price'] - $userProfile['avg_price']); ?> ₽</span>
                                        <?php else: ?>
                                            <span class="same">Такая же цена</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </span>
                            </div>
                            
                            <div class="cluster-info">
                                <small>Подходит под ваш ценовой сегмент</small>
                            </div>
                            
                            <a href="product_page.php?id=<?php echo $product['id_product']; ?>" 
                               class="view-details-btn">
                                Посмотреть
                            </a>
                        </div>
                    </div>
                    <?php 
                        endwhile;
                    else:
                        echo '<p class="no-recommendations">Нет рекомендаций для отображения</p>';
                    endif;
                    ?>
                </div>
                
                <!-- Информация о кластерах -->
                <div class="clusters-info">
                    <h4>Ваши ценовые предпочтения:</h4>
                    <?php
                    $prices = [];
                    foreach ($cart_items as $item) {
                        $prices[] = $item['price'];
                    }
                    
                    if (count($prices) >= 3):
                        sort($prices);
                        $segmentSize = ceil(count($prices) / 3);
                        
                        echo '<div class="cluster-segments">';
                        for ($i = 0; $i < 3; $i++):
                            $segment = array_slice($prices, $i * $segmentSize, $segmentSize);
                            if (!empty($segment)):
                                $min = min($segment);
                                $max = max($segment);
                                $count = count($segment);
                    ?>
                        <div class="segment">
                            <div class="segment-name">Сегмент <?php echo $i+1; ?></div>
                            <div class="segment-range"><?php echo $min; ?> - <?php echo $max; ?> ₽</div>
                            <div class="segment-count"><?php echo $count; ?> товар(ов)</div>
                        </div>
                    <?php
                            endif;
                        endfor;
                        echo '</div>';
                    endif;
                    ?>
                </div>
            </div>
            
            <?php endif; ?>
        </div>
    </div>
    
    <script src="js/search.js"></script>
    
    <script>
    // JavaScript для визуализации ценовых кластеров
    document.addEventListener('DOMContentLoaded', function() {
        // Анимация появления рекомендаций
        const recommendationCards = document.querySelectorAll('.cluster-product-card');
        recommendationCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100 * index);
        });
        
        // Интерактивность для сегментов
        const segments = document.querySelectorAll('.segment');
        segments.forEach(segment => {
            segment.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.05)';
                this.style.transition = 'transform 0.3s ease';
            });
            
            segment.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
            });
        });
        
        // Подсказки для рекомендаций
        const productCards = document.querySelectorAll('.cluster-product-card');
        productCards.forEach(card => {
            const matchBadge = card.querySelector('.match-badge');
            const matchText = matchBadge.textContent;
            
            // Добавляем подсказку при наведении на бейдж
            matchBadge.title = getMatchDescription(matchText);
            
            // Анимация при наведении на карточку
            card.addEventListener('mouseenter', function() {
                const priceCompare = this.querySelector('.price-compare span');
                if (priceCompare) {
                    priceCompare.style.fontWeight = 'bold';
                }
            });
            
            card.addEventListener('mouseleave', function() {
                const priceCompare = this.querySelector('.price-compare span');
                if (priceCompare) {
                    priceCompare.style.fontWeight = 'normal';
                }
            });
        });
        
        function getMatchDescription(matchText) {
            const matchPercent = parseInt(matchText);
            if (matchPercent >= 80) {
                return 'Отличное совпадение с вашими предпочтениями!';
            } else if (matchPercent >= 60) {
                return 'Хорошее совпадение с вашим бюджетом';
            } else {
                return 'Умеренное совпадение, но может понравиться';
            }
        }
        
        // Анимация для бейджа профиля
        const profileBadge = document.querySelector('.user-profile-badge');
        if (profileBadge) {
            setTimeout(() => {
                profileBadge.style.boxShadow = '0 5px 15px rgba(0,0,0,0.1)';
                profileBadge.style.transition = 'box-shadow 0.5s ease';
            }, 500);
        }
    });
    </script>
    
</body>
</html>