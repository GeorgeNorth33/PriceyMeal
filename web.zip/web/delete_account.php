<?php
// delete_account.php - разместить в корневой папке с profile.php
session_start();

// Настройки подключения к БД (используем те же, что в profile.php)
$host = '127.0.0.1:3307'; // или 'localhost'
$username = 'root';
$password = '';
$database = 'MealDB';

$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Начинаем транзакцию
mysqli_begin_transaction($connection);

try {
    // Удаляем данные из связанных таблиц
    $tables_to_clean = [
        "DELETE FROM UserFavorites WHERE user_id = $user_id",
        "DELETE FROM UserViewHistory WHERE user_id = $user_id", 
        "DELETE FROM UserRecommendations WHERE user_id = $user_id",
        "DELETE FROM UserPreferences WHERE user_id = $user_id",
        "DELETE FROM Cart WHERE id_user = $user_id"
    ];
    
    foreach ($tables_to_clean as $query) {
        mysqli_query($connection, $query);
    }
    
    // Удаляем пользователя
    $delete_user = "DELETE FROM users WHERE id_user = $user_id";
    $result = mysqli_query($connection, $delete_user);
    
    if ($result && mysqli_affected_rows($connection) > 0) {
        mysqli_commit($connection);
        
        // Очищаем сессию
        session_unset();
        session_destroy();
        
        // Перенаправляем на логин
        header("Location: login.php?account_deleted=1");
        exit();
    } else {
        throw new Exception("Не удалось удалить пользователя");
    }
    
} catch (Exception $e) {
    mysqli_rollback($connection);
    $_SESSION['error_message'] = "Ошибка при удалении: " . $e->getMessage();
    header("Location: profile.php");
    exit();
}
?>