<?php
session_start();

// Если аккаунт был удален, показываем специальное сообщение
if (isset($_GET['account_deleted']) && $_GET['account_deleted'] == 1) {
    // Выводим полную HTML-страницу с сообщением об удалении
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Аккаунт удален - Pricey Meal</title>
        <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: 'Ubuntu', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, sans-serif;
            }

            body {
                background-color: #E7F1F4;
                font-family: 'Ubuntu', sans-serif;
            }

            .deleted-success-container {
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                padding: 20px;
                background-color: #E7F1F4;
            }

            .deleted-success-card {
                background: white;
                border-radius: 16px;
                padding: 40px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                text-align: center;
                max-width: 450px;
                width: 100%;
                border: 1px solid #e0e0e0;
            }

            .success-header {
                margin-bottom: 25px;
            }

            .success-icon {
                width: 80px;
                height: 80px;
                background: #d4edda;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 20px;
                color: #155724;
                border: 3px solid #c3e6cb;
            }

            .success-icon svg {
                width: 40px;
                height: 40px;
            }

            .deleted-success-card h3 {
                color: #155724;
                font-size: 24px;
                font-weight: 700;
                margin: 0;
                font-family: 'Ubuntu', sans-serif;
            }

            .success-body p {
                color: #666;
                font-size: 16px;
                line-height: 1.6;
                margin-bottom: 30px;
                font-family: 'Ubuntu', sans-serif;
            }

            .success-actions {
                display: flex;
                flex-direction: column;
                gap: 12px;
            }

            .btn {
                padding: 14px 20px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: 600;
                font-size: 15px;
                transition: all 0.3s ease;
                border: none;
                cursor: pointer;
                display: block;
                font-family: 'Ubuntu', sans-serif;
            }

            .success-btn {
                background: #037D86;
                color: white;
            }

            .success-btn:hover {
                background: #04a7b3;
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(3, 125, 134, 0.3);
            }

            .outline-btn {
                background: transparent;
                color: #037D86;
                border: 2px solid #037D86;
            }

            .outline-btn:hover {
                background: #037D86;
                color: white;
                transform: translateY(-2px);
            }

            @media (max-width: 768px) {
                .deleted-success-card {
                    padding: 30px 25px;
                    margin: 20px;
                }
                
                .success-icon {
                    width: 70px;
                    height: 70px;
                }
                
                .success-icon svg {
                    width: 35px;
                    height: 35px;
                }
                
                .deleted-success-card h3 {
                    font-size: 22px;
                }
            }

            @media (max-width: 480px) {
                .deleted-success-card {
                    padding: 25px 20px;
                }
                
                .success-actions {
                    gap: 10px;
                }
                
                .btn {
                    padding: 12px 16px;
                    font-size: 14px;
                }
            }
        </style>
    </head>
    <body>
        <div class="deleted-success-container">
            <div class="deleted-success-card">
                <div class="success-header">
                    <div class="success-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                    </div>
                    <h3>Аккаунт удален</h3>
                </div>
                <div class="success-body">
                    <p>Ваш аккаунт и все связанные данные были успешно удалены из системы.</p>
                    <div class="success-actions">
                        <a href="register.php" class="btn success-btn">Зарегистрироваться снова</a>
                        <a href="index.php" class="btn outline-btn">Вернуться на сайт</a>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit(); // Завершаем выполнение
}

// Обычная логика входа
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    require_once 'includes/db_connection.php';
    
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $password = mysqli_real_escape_string($connection, $_POST['password']);
    
    $query = "SELECT * FROM users WHERE Email = '$email' AND Password = '$password'";
    $result = mysqli_query($connection, $query);
    
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['user_id'] = $user['id_user'];
        $_SESSION['user_name'] = $user['FirstName'] . ' ' . $user['SecondName'];
        $_SESSION['user_email'] = $user['Email'];
        
        header("Location: index.php");
        exit();
    } else {
        $error = "Неверный email или пароль";
    }
}

// Если пользователь уже авторизован, перенаправляем на главную
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход - Pricey Meal</title>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/profile.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Ubuntu', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, sans-serif;
        }

        body {
            background-color: #E7F1F4;
            font-family: 'Ubuntu', sans-serif;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #E7F1F4;
            padding: 20px;
        }

        .login-card {
            background: white;
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            border: 1px solid #e0e0e0;
        }

        .login-logo {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-logo img {
            height: 60px;
            width: auto;
        }

        .login-title {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            font-size: 28px;
            font-weight: 700;
            font-family: 'Ubuntu', sans-serif;
        }

        .login-form {
            width: 100%;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
            font-family: 'Ubuntu', sans-serif;
        }

        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s;
            background-color: white;
            font-family: 'Ubuntu', sans-serif;
        }

        .form-group input:focus {
            outline: none;
            border-color: #037D86;
            box-shadow: 0 0 0 3px rgba(3, 125, 134, 0.1);
        }

        .login-btn {
            width: 100%;
            padding: 15px;
            background: #037D86;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
            font-family: 'Ubuntu', sans-serif;
        }

        .login-btn:hover {
            background: #04a7b3;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(3, 125, 134, 0.3);
        }

        .login-links {
            text-align: center;
            margin-top: 25px;
            padding-top: 25px;
            border-top: 1px solid #e0e0e0;
            font-family: 'Ubuntu', sans-serif;
        }

        .login-links a {
            color: #037D86;
            text-decoration: none;
            font-weight: 500;
            font-size: 15px;
            transition: color 0.3s;
            font-family: 'Ubuntu', sans-serif;
        }

        .login-links a:hover {
            color: #04a7b3;
            text-decoration: underline;
        }

        .login-links p {
            margin-bottom: 10px;
            font-family: 'Ubuntu', sans-serif;
        }

        .error-message {
            color: #dc3545;
            background-color: #f8d7da;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
            text-align: center;
            font-family: 'Ubuntu', sans-serif;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <!-- Обычная форма входа -->
    <div class="login-container">
        <div class="login-card">
            <div class="login-logo">
                <a href="index.php"><img src="img/logo_logo копия.png" alt="Pricey Meal"></a>
            </div>
            
            <h1 class="login-title">Вход в аккаунт</h1>
            
            <?php if (!empty($error)): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form class="login-form" method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Введите ваш email" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Пароль</label>
                    <input type="password" id="password" name="password" placeholder="Введите ваш пароль" required>
                </div>
                
                <button type="submit" name="login" class="login-btn">Войти</button>
            </form>
            
            <div class="login-links">
                <p>Нет аккаунта? <a href="register.php">Зарегистрируйтесь</a></p>
                <p><a href="index.php">Вернуться на главную</a></p>
            </div>
        </div>
    </div>
</body>
</html>