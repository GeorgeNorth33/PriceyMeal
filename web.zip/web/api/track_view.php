<?php
session_start();
require '../includes/db_connection.php';

if (!isset($_SESSION['user_id'])) {
    exit;
}

$user_id = $_SESSION['user_id'];
$product_id = $_POST['product_id'];

// Сохраняем просмотр в историю
$query = "
    INSERT INTO UserViewHistory (user_id, product_id, viewed_at) 
    VALUES (?, ?, NOW())
    ON DUPLICATE KEY UPDATE viewed_at = NOW()
";

$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "ii", $user_id, $product_id);
mysqli_stmt_execute($stmt);
?>