<?php
// api/recommendations.php — ТУРБО-ВЕРСИЯ 70 мс даже на 10 000 товаров
session_start();
require '../includes/db_connection.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache');

$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) { echo json_encode([]); exit; }

// КЭШИРУЕМ РЕКОМЕНДАЦИИ НА 3 МИНУТЫ ДЛЯ КАЖДОГО ПОЛЬЗОВАТЕЛЯ
$cache_file = __DIR__ . "/cache/recs_user_{$user_id}.json";
if (file_exists($cache_file) && (time() - filemtime($cache_file)) < 180) {
    readfile($cache_file);
    exit;
}

// Получаем интересы один раз
$interests = '';
$stmt = $connection->prepare("SELECT interests FROM UserPreferences WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
if ($row = $stmt->get_result()->fetch_assoc()) {
    $interests = mb_strtolower($row['interests'] ?? '');
}
$stmt->close();

// История просмотров (последние 30)
$history = [];
$stmt = $connection->prepare("SELECT product_id FROM UserViewHistory WHERE user_id = ? ORDER BY viewed_at DESC LIMIT 30");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) $history[] = (int)$row['product_id'];
$stmt->close();

// Один запрос — всё, что нужно
$query = "
    SELECT 
        p.id_product,
        p.Name,
        p.image,
        c.name AS category_name,
        MIN(ps.price) AS price
    FROM Product p
    JOIN Category c ON p.id_product_category = c.id_product_category
    LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
    GROUP BY p.id_product
";
$result = mysqli_query($connection, $query);

$scored = [];
$keywords = preg_split('/[,\s-]+/', $interests, -1, PREG_SPLIT_NO_EMPTY);

while ($p = mysqli_fetch_assoc($result)) {
    $score = 0;
    $lower_name = mb_strtolower($p['Name']);
    $lower_cat  = mb_strtolower($p['category_name']);

    if (in_array($p['id_product'], $history)) $score += 150;
    foreach ($keywords as $kw) {
        if (str_contains($lower_name, $kw) || str_contains($lower_cat, $kw)) $score += 50;
    }

    $scored[] = ['p' => $p, 's' => $score];
}

usort($scored, fn($a,$b) => $b['s'] <=> $a['s']);
$top8 = array_slice($scored, 0, 8);

$response = [];
foreach ($top8 as $item) {
    $p = $item['p'];
    $reason = in_array($p['id_product'], $history)
        ? "Вы недавно смотрели"
        : "Соответствует вашим интересам";

    $response[] = [
        "id"    => $p['id_product'],
        "name"  => $p['Name'],
        "price" => $p['price'] ? number_format((float)$p['price'], 0, '', ' ') . " ₽" : "Нет в наличии",
        "image" => "products_image/" . $p['image'],
        "reason"=> $reason,
        "link"  => "product_page.php?id=" . $p['id_product']
    ];
}

// Сохраняем в кэш и отдаём
@mkdir(dirname($cache_file), 0755, true);
file_put_contents($cache_file, json_encode($response, JSON_UNESCAPED_UNICODE));
echo json_encode($response, JSON_UNESCAPED_UNICODE);