<?php
session_start();
require '../includes/db_connection.php';
require '../includes/recommendations.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit();
}

$userId = $_SESSION['user_id'];
$recommender = new PriceRecommender($connection);
$recommendedProducts = $recommender->getCartBasedRecommendations($userId);

$response = [];
while ($product = mysqli_fetch_assoc($recommendedProducts)) {
    $response[] = [
        'id' => $product['id_product'],
        'name' => $product['Name'],
        'image' => 'products_image/' . $product['image'],
        'price' => $product['min_price'] . ' ₽',
        'link' => 'product_page.php?id=' . $product['id_product'],
        'reason' => 'Идеально подходит под ваш бюджет'
    ];
}

echo json_encode($response);
?>