<!DOCTYPE html>
<html lang="ru">
<?
session_start();
require 'includes/db_connection.php';

// Проверяем авторизацию
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$version = '1.0.' . time();

// Получаем данные пользователя
$user_id = $_SESSION['user_id'];
$query_user = "SELECT * FROM users WHERE id_user = $user_id";
$result_user = mysqli_query($connection, $query_user);
$user = mysqli_fetch_assoc($result_user);

// Обработка формы обновления данных
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $first_name = mysqli_real_escape_string($connection, $_POST['first_name']);
    $second_name = mysqli_real_escape_string($connection, $_POST['second_name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $phone = mysqli_real_escape_string($connection, $_POST['phone']);
    
    $update_query = "UPDATE users SET 
                    FirstName = '$first_name',
                    SecondName = '$second_name',
                    Email = '$email',
                    PhoneNumber = '$phone'
                    WHERE id_user = $user_id";
    
    if (mysqli_query($connection, $update_query)) {
        $success_message = "Данные успешно обновлены!";
        // Обновляем данные в сессии
        $_SESSION['user_name'] = $first_name . ' ' . $second_name;
        // Перезагружаем страницу для отображения обновленных данных
        header("Location: profile.php");
        exit();
    } else {
        $error_message = "Ошибка при обновлении данных: " . mysqli_error($connection);
    }
}

// Обработка экспорта данных
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['export_data'])) {
    // Получаем все данные пользователя
    $user_query = "SELECT * FROM users WHERE id_user = $user_id";
    $user_result = mysqli_query($connection, $user_query);
    $user_data = mysqli_fetch_assoc($user_result);
    
    // Получаем избранные товары (исправленный запрос без Description)
    $favorites_query = "
        SELECT p.Name, p.Calories, p.Proteins, p.Fats, p.Carbohydrates,
               MIN(ps.price) as min_price, f.created_at as added_date
        FROM UserFavorites f
        JOIN Product p ON f.product_id = p.id_product
        LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
        WHERE f.user_id = $user_id
        GROUP BY p.id_product
        ORDER BY f.created_at DESC
    ";
    $favorites_result = mysqli_query($connection, $favorites_query);
    $favorites_data = [];
    while ($row = mysqli_fetch_assoc($favorites_result)) {
        $favorites_data[] = $row;
    }
    
    // Формируем данные для экспорта
    $export_data = [
        'user_info' => [
            'first_name' => $user_data['FirstName'],
            'second_name' => $user_data['SecondName'],
            'email' => $user_data['Email'],
            'phone' => $user_data['PhoneNumber'],
            'gender' => $user_data['Gender'],
            'date_of_birth' => $user_data['DateBirth'],
            'registration_date' => $user_data['RegistrationDate']
        ],
        'favorites' => $favorites_data,
        'export_date' => date('Y-m-d H:i:s'),
        'total_favorites' => count($favorites_data)
    ];
    
    // Генерируем JSON файл
    $json_data = json_encode($export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $filename = "user_data_" . $user_data['FirstName'] . "_" . date('Y-m-d') . ".json";
    
    // Отправляем файл для скачивания
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($json_data));
    echo $json_data;
    exit();
}

// Функция для безопасного вывода данных
function safe_echo($data) {
    if ($data === null || $data === '') {
        return 'Не указано';
    }
    return htmlspecialchars($data);
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль - Pricey Meal</title>
    <link rel="stylesheet" href="/profile.css?v=<?php echo $version ?>">
    <script src="/js/profile.js"></script>
</head>
<body>
    <header class="header">
        <div class="logo-container">
            <a href="index.php"><img src="img/logo_logo копия.png" alt="logo"></a>
        </div>

        
        <div class="header-actions">
            <div class="action-item">
                <a href="cart_page.php" class="action-icon"><img src="icons/icons8-cart-35 .png" alt="cart"></a>
                <a href="cart_page.php" class="action-label">Корзина</a>
            </div>
            <div class="action-item">
                <a href="profile.php" class="action-icon"><img src="icons/icons8-user-icon-35.png" alt="profile"></a>
                <a href="profile.php" class="action-label">Профиль</a>
            </div>
            <div class="action-item">
                <a href="logout.php" class="action-icon"><img src="icons/exit.png" alt="profile"></a>
                <a href="logout.php" class="action-label">Выйти</a>
            </div>
        </div>
    </header>

    <div class="main-container">
        <div class="profile-page">
            <!-- Боковая навигация -->
            <aside class="profile-sidebar">
                <div class="user-card">
                    <h2 class="user-name"><?php echo safe_echo($user['FirstName']) . ' ' . safe_echo($user['SecondName']); ?></h2>
                    <p class="user-email"><?php echo safe_echo($user['Email']); ?></p>
                </div>
                
                <nav class="profile-nav">
                    <a href="#personal" class="nav-item active">Личные данные</a>
                    <a href="#favorites" class="nav-item">Избранное</a>
                    <a href="#settings" class="nav-item">Настройки</a>
                </nav>
            </aside>

            <!-- Основной контент -->
            <main class="profile-content">
                <!-- Сообщения об успехе/ошибке -->
                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>
                
                <?php if (isset($error_message)): ?>
                    <div class="alert alert-error"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <!-- Раздел личных данных -->
                <section id="personal" class="content-section active">
                    <h2>Личные данные</h2>
                    <form class="profile-form" method="POST">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Имя</label>
                                <input type="text" name="first_name" 
                                       value="<?php echo safe_echo($user['FirstName']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Фамилия</label>
                                <input type="text" name="second_name" 
                                       value="<?php echo safe_echo($user['SecondName']); ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" placeholder="Почта" 
                                   value="<?php echo safe_echo($user['Email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Телефон</label>
                            <input type="tel" name="phone" placeholder="Номер телефона" 
                                   value="<?php echo safe_echo($user['PhoneNumber']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Пол</label>
                            <input type="text" value="<?php echo safe_echo($user['Gender']); ?>" disabled>
                        </div>
                        <div class="form-group disabled-field">
                            <label>Дата рождения</label>
                            <input type="text" value="<?php echo safe_echo($user['DateBirth']); ?>" disabled>
                        </div>
  
                        <button type="submit" name="update_profile" class="save-btn">Сохранить изменения</button>
                    </form>
                </section>

            <!-- Раздел избранного -->
            <section id="favorites" class="content-section">
                <h2>Избранные товары</h2>
                <div class="favorites-grid" id="favoritesGrid">
                    <?php
                    // Получаем избранные товары пользователя
                    $favorites_query = "
                        SELECT p.*, 
                            MIN(ps.price) as min_price,
                            f.created_at,
                            f.id as favorite_id
                        FROM UserFavorites f
                        JOIN Product p ON f.product_id = p.id_product
                        LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                        WHERE f.user_id = $user_id
                        GROUP BY p.id_product
                        ORDER BY f.created_at DESC
                    ";
                    $favorites_result = mysqli_query($connection, $favorites_query);
                    
                    if (mysqli_num_rows($favorites_result) > 0) {
                        while ($favorite = mysqli_fetch_assoc($favorites_result)) {
                            ?>
                            <div class="favorite-item" data-product-id="<?php echo $favorite['id_product']; ?>" id="favorite-<?php echo $favorite['id_product']; ?>">
                                <a href="product_page.php?id=<?php echo $favorite['id_product']; ?>" class="favorite-image">
                                    <img src="products_image/<?php echo $favorite['image']; ?>" alt="<?php echo $favorite['Name']; ?>" onerror="this.src='img/placeholder.jpg'">
                                </a>
                                <div class="favorite-info">
                                    <div class="favorite-name"><?php echo $favorite['Name']; ?></div>
                                    <div class="favorite-price"><?php echo $favorite['min_price'] ? $favorite['min_price'] . ' ₽' : 'Цена не указана'; ?></div>
                                </div>
                                <button class="remove-favorite-btn" 
                                        data-product-id="<?php echo $favorite['id_product']; ?>"
                                        onclick="removeFromFavorites(<?php echo $favorite['id_product']; ?>)">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                                    </svg>
                                    Удалить
                                </button>
                            </div>
                            <?php
                        }
                    } else {
                        echo '<p style="text-align: center; color: #666; grid-column: 1 / -1;">У вас пока нет избранных товаров</p>';
                    }
                    ?>
                </div>
            </section>

                <section id="settings" class="content-section">
                    <h2>Настройки</h2>
                    <div class="settings-list">
                        <!-- Уведомления -->
                        <!-- <div class="setting-item">
                            <div class="setting-info">
                                <h3>Уведомления о скидках</h3>
                                <p>Получать уведомления об акциях и специальных предложениях</p>
                            </div>
                            <label class="switch">
                                <input type="checkbox" checked>
                                <span class="slider"></span>
                            </label>
                        </div> -->

                        <!-- <div class="setting-item">
                            <div class="setting-info">
                                <h3>Email-рассылка</h3>
                                <p>Получать новости и рекомендации на email</p>
                            </div>
                            <label class="switch">
                                <input type="checkbox" checked>
                                <span class="slider"></span>
                            </label>
                        </div> -->

                        <!-- Безопасность -->
                        <div class="setting-item">
                            <div class="setting-info">
                                <h3>Смена пароля</h3>
                                <p>Изменить пароль вашего аккаунта</p>
                            </div>
                            <a href="change_password.php" class="change-password-btn">Сменить пароль</a>
                        </div>

                        <!-- Управление данными -->
                        <div class="setting-item">
                            <div class="setting-info">
                                <h3>Экспорт данных</h3>
                                <p>Скачать все ваши персональные данные в формате JSON</p>
                            </div>
                            <form method="POST" style="display: inline;">
                                <button type="submit" name="export_data" class="export-btn">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                                        <polyline points="7 10 12 15 17 10"/>
                                        <line x1="12" y1="15" x2="12" y2="3"/>
                                    </svg>
                                    Экспорт данных
                                </button>
                            </form>
                        </div>

                        <div class="setting-item">
                            <div class="setting-info">
                                <h3>Удаление аккаунта</h3>
                                <p>Безвозвратно удалить аккаунт и все данные</p>
                            </div>
                            <button class="delete-btn" onclick="confirmDelete()">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
                                    <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                                </svg>
                                Удалить аккаунт
                            </button>
                        </div>
                    </div>
                </section>
            </main>
        </div>
    </div>

    <script>
        function confirmDelete() {
            if (confirm('ВНИМАНИЕ! Вы уверены, что хотите удалить аккаунт? Это действие нельзя отменить. Все ваши данные будут безвозвратно удалены.')) {
                window.location.href = 'delete_account.php';
            }
        }
    </script>

    <script src="js/favorites.js"></script>

</body>
</html>