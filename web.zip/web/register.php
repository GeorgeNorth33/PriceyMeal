<!DOCTYPE html>
<html lang="ru">
<?php
session_start();
require 'includes/db_connection.php';

$version = '1.0' . time();
// Обработка формы регистрации
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = mysqli_real_escape_string($connection, $_POST['first_name']);
    $second_name = mysqli_real_escape_string($connection, $_POST['second_name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $password = mysqli_real_escape_string($connection, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($connection, $_POST['confirm_password']);
    $gender = mysqli_real_escape_string($connection, $_POST['gender']);
    $date_birth = mysqli_real_escape_string($connection, $_POST['date_birth']);
    
    // Проверка совпадения паролей
    if ($password !== $confirm_password) {
        $error_message = "Пароли не совпадают";
    } else {
        // Проверка существования email
        $check_query = "SELECT * FROM users WHERE Email = '$email'";
        $check_result = mysqli_query($connection, $check_query);
        
        if (mysqli_num_rows($check_result) > 0) {
            $error_message = "Пользователь с таким email уже существует";
        } else {
            // Валидация даты рождения (без ограничения по возрасту)
            if (!empty($date_birth)) {
                $min_date = strtotime('-120 years'); // Минимальная дата - 120 лет назад
                $max_date = strtotime('today'); // Максимальная дата - сегодня
                $user_birth = strtotime($date_birth);
                
                if ($user_birth < $min_date || $user_birth > $max_date) {
                    $error_message = "Пожалуйста, введите корректную дату рождения";
                } else {
                    // Вставка нового пользователя с датой рождения
                    $insert_query = "INSERT INTO users (FirstName, SecondName, Email, Password, PhoneNumber, Gender, DateBirth) 
                                    VALUES ('$first_name', '$second_name', '$email', '$password', '', '$gender', '$date_birth')";
                    
                    if (mysqli_query($connection, $insert_query)) {
                        // Получаем ID нового пользователя
                        $user_id = mysqli_insert_id($connection);
                        
                        // Устанавливаем сессию
                        $_SESSION['user_id'] = $user_id;
                        $_SESSION['user_name'] = $first_name . ' ' . $second_name;
                        $_SESSION['user_email'] = $email;
                        
                        // Перенаправляем на главную страницу
                        header("Location: index.php");
                        exit();
                    } else {
                        $error_message = "Ошибка регистрации: " . mysqli_error($connection);
                    }
                }
            } else {
                // Если дата рождения не указана, использовать NULL
                $insert_query = "INSERT INTO users (FirstName, SecondName, Email, Password, PhoneNumber, Gender, DateBirth) 
                                VALUES ('$first_name', '$second_name', '$email', '$password', '', '$gender', NULL)";
                
                if (mysqli_query($connection, $insert_query)) {
                    // Получаем ID нового пользователя
                    $user_id = mysqli_insert_id($connection);
                    
                    // Устанавливаем сессию
                    $_SESSION['user_id'] = $user_id;
                    $_SESSION['user_name'] = $first_name . ' ' . $second_name;
                    $_SESSION['user_email'] = $email;
                    
                    // Перенаправляем на главную страницу
                    header("Location: index.php");
                    exit();
                } else {
                    $error_message = "Ошибка регистрации: " . mysqli_error($connection);
                }
            }
        }
    }
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Pricey Meal</title>
    <link rel="stylesheet" href="/register.css?=<?php echo $version?>">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="register-container">
        <div class="register-card">
            <div class="register-logo">
                <a href="index.php"><img src="img/logo_logo копия.png" alt="Pricey Meal"></a>
            </div>
            
            <h1 class="register-title">Регистрация</h1>
            
            <?php if (isset($error_message)): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <form class="register-form" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">Имя</label>
                        <input type="text" id="first_name" name="first_name" placeholder="Введите имя" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="second_name">Фамилия</label>
                        <input type="text" id="second_name" name="second_name" placeholder="Введите фамилию" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="example@mail.ru" required>
                </div>

                <div class="form-group">
                    <label for="date_birth">Дата рождения</label>
                    <input type="date" id="date_birth" name="date_birth" 
                           max="<?php echo date('Y-m-d'); ?>"
                           onchange="calculateAge(this)">
                </div>

                <div class="form-group">
                    <label>Пол</label>
                    <div class="gender-options">
                        <label class="gender-option">
                            <input type="radio" name="gender" value="М" class="gender-radio" required>
                            <span class="gender-label">Мужской</span>
                        </label>
                        <label class="gender-option">
                            <input type="radio" name="gender" value="Ж" class="gender-radio" required>
                            <span class="gender-label">Женский</span>
                        </label>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="password">Пароль</label>
                        <input type="password" id="password" name="password" placeholder="Введите пароль" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Подтвердите пароль</label>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Повторите пароль" required>
                    </div>
                </div>
                
                <button type="submit" class="register-btn">Зарегистрироваться</button>
            </form>
            
            <div class="register-links">
                <p>Уже есть аккаунт? <a href="login.php">Войти</a></p>
                <p><a href="index.php">Вернуться на главную</a></p>
            </div>
        </div>
    </div>

    <script>
    function calculateAge(input) {
        const selectedDate = new Date(input.value);
        const today = new Date();
        
        if (input.value) {
            let age = today.getFullYear() - selectedDate.getFullYear();
            const monthDiff = today.getMonth() - selectedDate.getMonth();
            
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < selectedDate.getDate())) {
                age--;
            }
            
            if (age < 0) {
                input.value = '';
            }
        }
    }

    // Устанавливаем максимальную дату (сегодня)
    document.addEventListener('DOMContentLoaded', function() {
        const dateInput = document.getElementById('date_birth');
        const maxDate = new Date();
        dateInput.max = maxDate.toISOString().split('T')[0];
        
        // Устанавливаем разумную минимальную дату (120 лет назад)
        const minDate = new Date();
        minDate.setFullYear(minDate.getFullYear() - 120);
        dateInput.min = minDate.toISOString().split('T')[0];
    });
    </script>
</body>
</html>