    <header class="header">
       <div class="search-container">
    <div class="search-wrapper">
        <input type="text" class="search-input" placeholder="Поиск товаров...">
        <button class="search-btn" aria-label="Найти">
            <img src="icons/icons8-loupe-25-black.png" alt="Найти" width="16" height="16">
        </button>
    </div>
</div>
        
<div class="header-actions">
    <div class="action-item">
        <a href="#" class="action-icon"><img src="icons/icons8-cart-35.png" alt="cart"></a>
        <a href="#" class="action-label">Корзина</a>
    </div>
    <div class="action-item">
        <a href="login.html" class="action-icon"><img src="icons/icons8-user-icon-35.png" alt="profile"></a>
        <a href="login.html" class="action-label">Профиль</a>
    </div>
</div>
    </header>