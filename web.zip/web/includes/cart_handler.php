<?php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['action']) || !isset($input['cart_item'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
    exit();
}

$action = $input['action'];
$cart_item = $input['cart_item'];

// Инициализируем корзину если её нет
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($action === 'add') {
    // Проверяем, нет ли уже такого товара от того же магазина
    $found_index = -1;
    foreach ($_SESSION['cart'] as $index => $item) {
        if ($item['product_id'] == $cart_item['product_id'] && $item['store_id'] == $cart_item['store_id']) {
            $found_index = $index;
            break;
        }
    }
    
    if ($found_index >= 0) {
        // Увеличиваем количество существующего товара
        $_SESSION['cart'][$found_index]['quantity'] += $cart_item['quantity'];
    } else {
        // Добавляем новый товар
        $_SESSION['cart'][] = $cart_item;
    }
    
    $cart_count = count($_SESSION['cart']);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Товар добавлен в корзину',
        'cart_count' => $cart_count
    ]);
    
} else {
    echo json_encode(['success' => false, 'message' => 'Unknown action']);
}
?>