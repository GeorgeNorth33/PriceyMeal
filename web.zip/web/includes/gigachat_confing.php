<?php
// Конфигурация GigaChat API
define('GIGACHAT_CLIENT_ID', 'ваш_client_id');
define('GIGACHAT_CLIENT_SECRET', 'ваш_client_secret');
define('GIGACHAT_AUTH_CODE', 'ваш_auth_code');

// Включить/выключить GigaChat
define('GIGACHAT_ENABLED', true);
?>