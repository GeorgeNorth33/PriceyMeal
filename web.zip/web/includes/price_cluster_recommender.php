<?php
// includes/price_cluster_recommender.php

class PriceClusterRecommender {
    private $connection;
    
    public function __construct($conn) {
        $this->connection = $conn;
    }
    
    /**
     * Основной метод: рекомендации на основе кластеризации цен
     */
    public function getRecommendationsByPriceClusters($cartItems, $limit = 5) {
        if (empty($cartItems)) {
            return $this->getPopularProducts($limit);
        }
        
        // 1. Извлекаем цены из корзины
        $cartPrices = $this->extractPricesFromCart($cartItems);
        
        // 2. Создаем кластеры цен
        $clusters = $this->createPriceClusters($cartPrices);
        
        // 3. Находим самый предпочтительный кластер
        $preferredCluster = $this->getPreferredCluster($clusters, $cartPrices);
        
        // 4. Получаем товары из этого кластера
        return $this->getProductsFromCluster($preferredCluster, $limit, $cartItems);
    }
    
    /**
     * Извлекаем цены из корзины
     */
    private function extractPricesFromCart($cartItems) {
        $prices = [];
        foreach ($cartItems as $item) {
            if (isset($item['price']) && $item['price'] > 0) {
                $prices[] = floatval($item['price']);
            }
        }
        return $prices;
    }
    
    /**
     * Создаем кластеры цен (адаптация Python алгоритма)
     */
    private function createPriceClusters($prices) {
        if (count($prices) < 3) {
            // Если мало товаров, создаем один кластер
            return [['min' => min($prices), 'max' => max($prices), 
                    'avg' => array_sum($prices) / count($prices),
                    'count' => count($prices)]];
        }
        
        sort($prices);
        $clusters = [];
        
        // Оптимальное количество кластеров (от 2 до 4)
        $numClusters = min(4, max(2, floor(count($prices) / 2)));
        $clusterSize = ceil(count($prices) / $numClusters);
        
        for ($i = 0; $i < count($prices); $i += $clusterSize) {
            $clusterPrices = array_slice($prices, $i, $clusterSize);
            if (!empty($clusterPrices)) {
                $clusters[] = [
                    'min' => min($clusterPrices),
                    'max' => max($clusterPrices),
                    'avg' => array_sum($clusterPrices) / count($clusterPrices),
                    'count' => count($clusterPrices),
                    'range' => max($clusterPrices) - min($clusterPrices)
                ];
            }
        }
        
        return $clusters;
    }
    
    /**
     * Определяем предпочтительный кластер
     * Алгоритм: учитываем частоту покупок и бюджет
     */
    private function getPreferredCluster($clusters, $allPrices) {
        if (count($clusters) == 1) {
            return $clusters[0];
        }
        
        $totalItems = count($allPrices);
        $preferred = null;
        $maxScore = -1;
        
        foreach ($clusters as $cluster) {
            // Балльная система для выбора лучшего кластера
            $score = 0;
            
            // 1. Частота покупок в этом кластере (40%)
            $frequencyScore = ($cluster['count'] / $totalItems) * 40;
            
            // 2. Стабильность цен в кластере (30%)
            $stabilityScore = 0;
            if ($cluster['range'] > 0) {
                // Чем меньше разброс цен, тем стабильнее кластер
                $stabilityScore = (1 / (1 + $cluster['range'])) * 30;
            }
            
            // 3. Привлекательность средней цены (30%)
            // Предполагаем, что средние цены (не самые дешевые и не самые дорогие) более привлекательны
            $globalAvg = array_sum($allPrices) / $totalItems;
            $priceAttractiveness = 1 / (1 + abs($cluster['avg'] - $globalAvg));
            $priceScore = $priceAttractiveness * 30;
            
            $totalScore = $frequencyScore + $stabilityScore + $priceScore;
            
            if ($totalScore > $maxScore) {
                $maxScore = $totalScore;
                $preferred = $cluster;
            }
        }
        
        return $preferred;
    }
    
    /**
     * Получаем товары из выбранного кластера
     */
    private function getProductsFromCluster($cluster, $limit, $cartItems) {
        // Получаем ID товаров, которые уже в корзине
        $cartProductIds = [];
        foreach ($cartItems as $item) {
            if (isset($item['product_id'])) {
                $cartProductIds[] = intval($item['product_id']);
            }
        }
        
        $cartIdsString = !empty($cartProductIds) ? 
            "AND p.id_product NOT IN (" . implode(',', $cartProductIds) . ")" : "";
        
        // Расширяем диапазон на 20% для большего выбора
        $expandedMin = $cluster['min'] * 0.8;
        $expandedMax = $cluster['max'] * 1.2;
        
        // SQL запрос БЕЗ кириллических комментариев
        $query = "SELECT p.*, 
                         MIN(ps.price) as min_price,
                         -- Вычисляем соответствие цены
                         (1 - ABS((MIN(ps.price) - {$cluster['avg']}) / {$cluster['avg']})) * 100 as price_match_percent,
                         -- Учитываем популярность
                         (SELECT COUNT(*) FROM UserFavorites uf WHERE uf.product_id = p.id_product) as favorite_count
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  WHERE ps.price BETWEEN $expandedMin AND $expandedMax
                  $cartIdsString
                  GROUP BY p.id_product
                  HAVING price_match_percent > 60  -- Отбираем товары, которые достаточно близки
                  ORDER BY price_match_percent DESC, favorite_count DESC
                  LIMIT $limit";
        
        $result = mysqli_query($this->connection, $query);
        
        if (!$result || mysqli_num_rows($result) == 0) {
            // Если не нашли подходящих товаров, расширяем поиск
            return $this->getAlternativeProducts($cluster['avg'], $limit, $cartProductIds);
        }
        
        return $result;
    }
    
    /**
     * Альтернативный поиск, если в кластере мало товаров
     */
    private function getAlternativeProducts($targetPrice, $limit, $excludeIds) {
        $excludeString = !empty($excludeIds) ? 
            "AND p.id_product NOT IN (" . implode(',', $excludeIds) . ")" : "";
        
        // Ищем товары в диапазоне ±40% от целевой цены
        $lower = $targetPrice * 0.6;
        $upper = $targetPrice * 1.4;
        
        $query = "SELECT p.*, 
                         MIN(ps.price) as min_price,
                         ABS(MIN(ps.price) - $targetPrice) as price_diff
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  WHERE ps.price BETWEEN $lower AND $upper
                  $excludeString
                  GROUP BY p.id_product
                  ORDER BY price_diff ASC
                  LIMIT $limit";
        
        return mysqli_query($this->connection, $query);
    }
    
    /**
     * Резервный метод: популярные товары
     */
    private function getPopularProducts($limit) {
        $query = "SELECT p.*, 
                         MIN(ps.price) as min_price,
                         (SELECT COUNT(*) FROM UserFavorites WHERE product_id = p.id_product) as fav_count
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  GROUP BY p.id_product
                  ORDER BY fav_count DESC
                  LIMIT $limit";
        
        return mysqli_query($this->connection, $query);
    }
    
    /**
     * Дополнительный метод: анализ покупательского профиля
     */
    public function analyzeUserPriceProfile($cartItems) {
        $prices = $this->extractPricesFromCart($cartItems);
        
        if (empty($prices)) {
            return ['type' => 'new_user', 'message' => 'Новый пользователь', 'avg_price' => 0];
        }
        
        $avg = array_sum($prices) / count($prices);
        $min = min($prices);
        $max = max($prices);
        $range = $max - $min;
        
        // Определяем тип покупателя
        $profile = [
            'avg_price' => round($avg, 2),
            'price_range' => round($range, 2),
            'total_items' => count($prices)
        ];
        
        if ($range < $avg * 0.3) {
            $profile['type'] = 'consistent';
            $profile['message'] = 'Выбирает товары в одном ценовом диапазоне';
            $profile['preference'] = 'Стабильные цены';
        } elseif ($max > $avg * 2) {
            $profile['type'] = 'varied';
            $profile['message'] = 'Покупает как бюджетные, так и премиум товары';
            $profile['preference'] = 'Разнообразие';
        } else {
            $profile['type'] = 'moderate';
            $profile['message'] = 'Сбалансированный выбор';
            $profile['preference'] = 'Средний ценовой сегмент';
        }
        
        return $profile;
    }
}
?>