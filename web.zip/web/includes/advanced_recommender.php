<?php
class AdvancedPriceRecommender {
    private $connection;
    
    public function __construct($conn) {
        $this->connection = $conn;
    }
    
    /**
     * Алгоритм 1: На основе среднего значения (из Python примера 1)
     */
    public function recommendByAveragePrice($cartPrices, $limit = 5) {
        if (empty($cartPrices)) return $this->getRandomProducts($limit);
        
        $avgPrice = array_sum($cartPrices) / count($cartPrices);
        $priceRange = max($cartPrices) - min($cartPrices);
        $weight = 0.2; // Как в Python коде
        
        $lowerBound = $avgPrice - ($priceRange * $weight);
        $upperBound = $avgPrice + ($priceRange * $weight);
        
        // SQL запрос с вычислением score как в Python
        $query = "SELECT p.*, MIN(ps.price) as price,
                         (1 / (1 + ABS(MIN(ps.price) - $avgPrice))) as similarity_score
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  WHERE ps.price BETWEEN $lowerBound AND $upperBound
                  GROUP BY p.id_product
                  ORDER BY similarity_score DESC
                  LIMIT $limit";
        
        return mysqli_query($this->connection, $query);
    }
    
    /**
     * Алгоритм 2: Кластеризация по ценовым сегментам (адаптация Python примера 2)
     */
    public function recommendByPriceClusters($cartPrices, $limit = 5) {
        if (empty($cartPrices)) return $this->getRandomProducts($limit);
        
        sort($cartPrices);
        $clusters = [];
        $clusterSize = max(1, floor(count($cartPrices) / 3));
        
        // Создаем кластеры как в Python
        for ($i = 0; $i < count($cartPrices); $i += $clusterSize) {
            $cluster = array_slice($cartPrices, $i, $clusterSize);
            if (!empty($cluster)) {
                $clusters[] = [
                    'min' => min($cluster),
                    'max' => max($cluster),
                    'avg' => array_sum($cluster) / count($cluster),
                    'count' => count($cluster)
                ];
            }
        }
        
        // Для простоты берем самый частый кластер
        usort($clusters, function($a, $b) {
            return $b['count'] <=> $a['count'];
        });
        
        $mainCluster = $clusters[0] ?? null;
        if (!$mainCluster) return $this->getRandomProducts($limit);
        
        $query = "SELECT p.*, MIN(ps.price) as price,
                         (1 / (1 + ABS(MIN(ps.price) - {$mainCluster['avg']}))) * ({$mainCluster['count']}/" . count($cartPrices) . ") as cluster_score
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  WHERE ps.price BETWEEN {$mainCluster['min']} AND {$mainCluster['max']}
                  GROUP BY p.id_product
                  ORDER BY cluster_score DESC
                  LIMIT $limit";
        
        return mysqli_query($this->connection, $query);
    }
    
    /**
     * Алгоритм 3: Гибридная формула (адаптация Python примера 4)
     */
    public function hybridRecommendation($cartPrices, $userId = null, $limit = 5) {
        if (empty($cartPrices)) return $this->getRandomProducts($limit);
        
        $avgPrice = array_sum($cartPrices) / count($cartPrices);
        $priceStd = $this->calculateStandardDeviation($cartPrices);
        
        // Если стандартное отклонение маленькое, увеличиваем для лучших рекомендаций
        if ($priceStd < $avgPrice * 0.1) {
            $priceStd = $avgPrice * 0.3;
        }
        
        $query = "SELECT p.*, 
                         MIN(ps.price) as price,
                         -- Весовые коэффициенты как в Python
                         (0.4 * EXP(-0.5 * POW((MIN(ps.price) - $avgPrice) / $priceStd, 2))) +  -- price_proximity
                         (0.3 * 0.5) +  -- category_match (заглушка)
                         (0.2 * (RAND() * 0.5 + 0.5)) +  -- popularity (заглушка)
                         (0.1 * 0.5) as final_score     -- trend (заглушка)
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  GROUP BY p.id_product
                  HAVING final_score > 0.3
                  ORDER BY final_score DESC
                  LIMIT $limit";
        
        return mysqli_query($this->connection, $query);
    }
    
    /**
     * Вспомогательная функция: стандартное отклонение
     */
    private function calculateStandardDeviation($array) {
        $count = count($array);
        if ($count <= 1) return 0;
        
        $mean = array_sum($array) / $count;
        $sum = 0;
        
        foreach ($array as $value) {
            $sum += pow($value - $mean, 2);
        }
        
        return sqrt($sum / ($count - 1));
    }
    
    private function getRandomProducts($limit) {
        $query = "SELECT p.*, MIN(ps.price) as price
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  GROUP BY p.id_product
                  ORDER BY RAND()
                  LIMIT $limit";
        
        return mysqli_query($this->connection, $query);
    }
}
?>