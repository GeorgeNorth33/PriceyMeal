<?php
// includes/recommendations.php

class PriceRecommender {
    private $connection;
    
    public function __construct($conn) {
        $this->connection = $conn;
    }
    
    // Метод 1: Рекомендации на основе текущей корзины
    public function getCartBasedRecommendations($userId = null) {
        $cartPrices = $this->getCartPrices($userId);
        
        if (empty($cartPrices)) {
            return $this->getPopularProducts(5);
        }
        
        $avgPrice = array_sum($cartPrices) / count($cartPrices);
        $priceRange = max($cartPrices) - min($cartPrices);
        
        // Если все цены одинаковые, создаем искусственный диапазон
        if ($priceRange == 0) {
            $priceRange = $avgPrice * 0.3;
        }
        
        // Настройте эти коэффициенты под вашу логику
        $lowerBound = $avgPrice - ($priceRange * 0.3);
        $upperBound = $avgPrice + ($priceRange * 0.3);
        
        // Убедимся, что нижняя граница не отрицательная
        $lowerBound = max(0, $lowerBound);
        
        // Создаем безопасный запрос
        $lowerBound = floatval($lowerBound);
        $upperBound = floatval($upperBound);
        $avgPrice = floatval($avgPrice);
        
        $query = "SELECT p.*, 
                         MIN(ps.price) as min_price,
                         (1 / (1 + ABS(MIN(ps.price) - $avgPrice))) * 100 as match_score
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  WHERE ps.price BETWEEN $lowerBound AND $upperBound
                  GROUP BY p.id_product
                  ORDER BY match_score DESC
                  LIMIT 5";
        
        $result = mysqli_query($this->connection, $query);
        
        if (!$result) {
            // Если запрос не удался, возвращаем популярные товары
            return $this->getPopularProducts(5);
        }
        
        return $result;
    }
    
    // Метод 2: Рекомендации для главной страницы
    public function getHomepageRecommendations($userId = null) {
        if (!$userId) {
            return $this->getPopularProducts(8);
        }
        
        // Если есть история, используем персонализированные рекомендации
        $cartPrices = $this->getCartPrices($userId);
        
        if (empty($cartPrices)) {
            return $this->getPopularProducts(8);
        }
        
        return $this->getCartBasedRecommendations($userId);
    }
    
    private function getCartPrices($userId) {
        $prices = [];
        
        // Получаем цены из сессии корзины
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                if (isset($item['price'])) {
                    $prices[] = floatval($item['price']);
                }
            }
        }
        
        return $prices;
    }
    
    private function getPopularProducts($limit = 5) {
        $limit = intval($limit);
        
        $query = "SELECT p.*, 
                         MIN(ps.price) as min_price
                  FROM Product p
                  LEFT JOIN `Product Store` ps ON p.id_product = ps.id_product
                  GROUP BY p.id_product
                  ORDER BY p.id_product DESC
                  LIMIT $limit";
        
        return mysqli_query($this->connection, $query);
    }
}
?>